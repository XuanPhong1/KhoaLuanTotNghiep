<?php
$_['text_handling'] = 'Handling Fee';